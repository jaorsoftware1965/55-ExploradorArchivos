<?php
  // Obtiene las Variables para el error
  if (isset($_GET["archivo"]))
     $archivo = $_GET["archivo"];
  else
  	 $archivo = "Archivo no recibido para ejecución";
?>
<!DOCTYPE html>
<html>
<head>
	<title>Ejecución de Archivo</title>
	<!-- // Incluye bootstrap -->
	<?php include "bootstrap.html"; ?>
</head>
<body>
	<!-- Objeto Navbar de BootStrap -->
	<nav class="navbar navbar-expand-md bg-dark navbar-dark">
		<a class="navbar-brand" href="#">Ejecución</a>
	</nav>

    <!-- // Separador -->
    <br>

	<div class="container">
		
		<!-- The Modal -->
		<div class="modal-content">

			<!-- Modal Header -->
			<div class="modal-header">
				<h4 class="modal-title">
					<?php
					   echo "Ejecutando:".$archivo;
					?>
				</h4>				
			</div>

			<!-- Modal body -->
			<div class="modal-body">
				<?php
				  // Ejecuta el archivo
				  system($archivo, $retval);
				  //exec("exe",$lineas,$retval);
				  //shell_exec($archivo);				  
          if ($retval!=0)
             echo "Archivo no reconocido por el Sistema Operativo<br>";
          else              
             echo "Archivo ejecutado con éxito<br>";
				?>
			</div>

			
		</div>
	
	</div>
</body>
</html>