<?php
  
// Función para el Control de Errores
function LogDeErrores($numeroDeError, 
	                    $descripcion, 
	                    $fichero, 
	                    $linea, 
	                    $contexto)
{
   error_log("Error: [".$numeroDeError."] ".$descripcion." ".$fichero." ".$linea." ".json_encode($contexto)." \n\r", 3, "log_errores.txt");
}

// Función para listar los Directorios 	         
function listar_directorios_ruta($ruta,$dirPadre)
{
   // abrir un directorio y listarlo recursivo
   if (is_dir($ruta)) 
   {
      // Abre el Directorio
      if ($dh = opendir($ruta)) 
      {
         // Directorio accedido
   	     echo "<table class=table> \n";
	     echo "	      <thead>\n";
	     echo "	        <tr class=table-warning>\n";
	     echo "	          <th>Nombre</th>\n";
	     echo "	          <th>Tipo</th>\n";
	     echo "	          <th>Fecha</th>\n";
	     echo "	          <th>Tamaño Bytes</th>\n";
	     echo "	        </tr>\n";
         echo "	      </thead>\n";
	     echo "	      <tbody>\n";

         // Ciclo para leer el directorio
         while (($file = readdir($dh)) !== false) 
         {
         	// Verifica que no sea el punto
         	if ($file!=".")
         	{

     			// Verifica si es archivo o directorio
	         	if (filetype($ruta."\\".$file)=='file')
	         	    // Creo el renglon
	         	    echo "            <tr class=table-primary>\n";
	         	else
	                // Creo el renglon
	         	    echo "            <tr class=table-success>\n";
         		
                // Verifica si es directorio para poner enlace
                if (filetype($ruta."\\".$file)=='dir')
                {
                	// Verifica si es el Padre
                	if ($file=="..")
                	{
                       echo "              <td><a href='index.php?directorio=$dirPadre'>$file</a></td>\n";
                	}
                    else
                    {
                    	// Creo la Celda con el nombre del Directorio
	         	        echo "              <td><a href='index.php?directorio=$ruta\\$file'>$file</a></td>\n";
                    }
                   
                }
                else
                {
                   // Creo la Celda con el nombre del Archivo
	         	       echo "              <td><a target='_blank' href='ejecutar.php?archivo=$ruta\\$file'>$file</a></td>\n";	
                }	         	
	         	echo "              <td>".filetype($ruta."\\".$file)."</td>\n";
	         	echo "              <td>".date ("F d Y H:i:s.", filemtime($ruta."\\".$file))."</td>\n";
	         	echo "              <td align=right>".filesize($ruta."\\".$file)."</td>\n";

	         	// Cerramos el Renglon
	         	echo "            </tr>\n";
         	}
         }

         echo "          </tbody>\n";
		 echo "        </table>\n";
         closedir($dh);
      }
      else
         echo "<br>No pudo acceder al directorio";     
   }
   else
      echo "<br>No es ruta valida";
}

  // Establece el Manejador de Errores
  set_error_handler("LogDeErrores",  E_WARNING|E_NOTICE);

  // Verifica si existe el Directorio en GET
  if (!isset($_GET["directorio"]))
  	  $directorio =getcwd();
  else
  	  $directorio =$_GET["directorio"];

  // Obtiene el Padre
  $dir = explode("\\", $directorio);
  $dirPadre="";

  // Verifica si ya llegó al raiz
  if (count($dir)==2)
  	$dirPadre="C:\\";
  else
	  // Ciclo para crear el directorio padre
	  for ($contador=0; $contador<count($dir)-1;$contador++)
	  	  if ($contador < count($dir)-2)
	         $dirPadre .= $dir[$contador]."\\";
	      else
	      	 $dirPadre .= $dir[$contador];
?>

<!DOCTYPE html>
<html>
<head>
	<title>Explorador</title>

    <!-- // Incluye bootstrap -->
	<?php include "bootstrap.html"; ?>
	
    <!-- // Incluimos las reglas de estilo de la aplicación--> 
    <link rel="stylesheet" type="text/css" href="css/comandas.css" media="screen" />

  
</head>
<body>

	<!-- Objeto Navbar de BootStrap -->
	<nav class="navbar navbar-expand-md bg-dark navbar-dark">
		<a class="navbar-brand" href="#">Explorador de Archivos</a>
	</nav>
    
    <!-- // Separador -->
	<br>

	<!-- Contenedor Principal -->
	<div class="container">

		<!-- Encabezado  -->
		<h3>
		    <?php
		       echo"Directorio:$directorio";
		    ?>
		</h3>

		<?php
            // Lista los Archivo
	        listar_directorios_ruta($directorio,$dirPadre);	        
	  	?>

	</div>	

</body>
</html>
