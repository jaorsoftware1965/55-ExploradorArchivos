<?php

// Función para listar los directorios
function listar_directorios_ruta($ruta)
{
   // abrir un directorio y listarlo recursivo
   if (is_dir($ruta)) 
   {
      // Mensaje de Acceso
      echo "Accediendo al Directorio ...<br>";

      // Abre el Directorio
      if ($dh = opendir($ruta)) 
      {
         // Directorio accedido
         echo "Directorio abierto ...<br>";

         // Ciclo para leer el directorio
         while (($file = readdir($dh)) !== false) 
         {
            // Listando el Directorio
            echo "Nombre de archivo: $file";
            echo " : Tipo: " . filetype($ruta . $file);
            echo "<br>";

            // Verifica si es directorio
            if (is_dir($ruta . $file) && $file!="." && $file!="..")
            {
               //solo si el archivo es un directorio, distinto que "." y ".."
               echo "<br>Directorio: $ruta$file";
               listar_directorios_ruta($ruta . $file . "/");
            }
         }
      closedir($dh);
      }
      else
         echo "<br>No pudo acceder al directorio";     
   }
   else
      echo "<br>No es ruta valida";
}


// Imprime el POST
echo "POST<br>";
print_r($_POST);
echo "<br><br>";

// Verifica que haya llegado
if (isset($_POST["directorio"]))
{	
    // Obtiene el Directorio
    $directorio = $_POST["directorio"];

    // Lista los Archivo
	  listar_directorios_ruta($directorio);
}
else
{
	echo "No llegaron los datos<br>";
}

// Mensaje
echo "<br>Programa Terminado<br>";

?>